import React, {Component} from 'react';

class Newform extends Component{
    constructor(){
        super();
this.state=
{
    f_name:"",
    l_name:" ",
  
    newItems:[]

}
    }

    action=()=>{

        var name=this.refs.fname.value;
        var lastname=this.refs.lname.value;
        
        this.setState({f_name:name, l_name:lastname})

        var Items=this.state.newItems;

        console.log(Items)
        Items.push({f_name:name,l_name:lastname})

        this.setState({newItems:Items});


    }

    delrow=(i)=>{

        var Items=this.state.newItems;
        Items.splice(i,1);
        this.setState({newItems:Items});

    }

render(){



    return(
        <div>
            <form>First Name
         <input type="text" ref="fname"/><br/>
Last Name: <input type="text" ref="lname"/><br/>

<input type="button" value="submit" onClick={this.action}/>
            </form>

            <div>
               <p>
                   First Name is:{this.state.f_name}
                   </p>
                   <p>
                   Last Name:{this.state.l_name}
                    </p>
        </div>  

            <div>
                    {this.state.newItems.map((data,i)=><div> 

                                    {data.l_name}| {data.f_name} <input type="button" value="del" onClick={()=> this.delrow(i)} />
                    </div> )}
            </div>              
      </div>
    )
}
}
export default Newform