

const express = require('express');
const fs  = require('fs');

const app = express();

app.use(function(req, res, next) {
   
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();

  });

app.get('',(req,res)=>{ //'' default 

    res.json({code:11,msg:'response for services'})

});

app.get('/save-data',(req,res)=>{

        var n = req.query.name;
        var email = req.query.email;
        var pwd = req.query.pwd;

        //var str ="{name:'nitin',email:'nitinns@gmail.com',pwd:'fjhfgfh'}";
        var data = {name:n,email:email,pwd:pwd}; //object 
        console.log(data);
        var str  = JSON.stringify(data); //conert object string 
        
        fs.appendFile('users.json',str,(err)=>{

            if(err)
                throw err;
            else 
                console.log('data is saved');
        });

        res.json({code:200,msg:'success'})


})

app.listen(3010,()=>{
    console.log('server is running at port number 3010');
})



