import React,{Component} from 'react';
import Create from './Create'
import View from './View'
import Recent from './Recent'
import Report from './Report'
export default class Dashboard extends Component{

render(){
return(
    <div>
        <input type='button' value='Create' className='btn-info btn-lg'/>
        <input type='button' value='Recent' className='btn-warning btn-lg'/><br/>
        <input type='button' value='Report' className='btn-success btn-lg'/>
        <input type='button' value='View' className='btn-secondary btn-lg'/>
<div>
    <Create/>
    <View/>
    <Recent/>
    <Report/>

</div>

    </div>
)

}
}
    