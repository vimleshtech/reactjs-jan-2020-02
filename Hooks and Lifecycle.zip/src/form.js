import React,{Component} from 'react';

//anuradhajha071@gmail.com
class Form extends Component{

    constructor(){
        super();
        this.state ={

            name:'',
            lname:'',
            email:'',
            amt:0,
            items:[]
        }
    }

    btn_action=()=>{

                //alert('you have clicked ...on button');
                var name = this.refs.fname.value;
                var lname = this.refs.lname.value;
                var email = this.refs.email.value;
                var amt  = this.refs.basicsal.value;

                //alert(name);
                //alert(lname);
                //alert(email);
                //alert(amt);


                this.setState({name:name,lname:lname,email:email,amt:amt});
                var items = this.state.items; //read state data 
                items.push({name:name,lname:lname,email:email,amt:amt});

               this.setState({items:items});

                console.log(this.state.items);




    }

    render(){
        return(
           <div>
                <form>
                     
First Name: <input type="text" ref="fname"/> <br/>
Last name: <input type="text" ref="lname"/><br/>
Email: <input type="text" ref="email"/><br/>
Basic Sal:<input type="number" ref="basicsal"/><br/>
<input type="button" value="submit" onClick={this.btn_action}/>

                </form>

                <div>
                    <p>
                        Name is { this.state.name } {this.state.lname}
                        </p>
                        
                    <p>
                        Email id { this.state.email } 
                        </p>
                        
                        
                    <p>
                        amt is  { this.state.amt}
                        </p>
                        
                    </div>

           </div>
     
        );
    }
}
export default Form;