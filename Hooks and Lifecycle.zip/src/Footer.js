import React,{Component} from 'react';


class Footer extends Component{

    render(){

        return(
                <h1>
                            in footer 

                </h1>

        );
    }

}
export default Footer;