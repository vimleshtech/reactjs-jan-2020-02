import React,{Component} from 'react';
export default class Views extends Component{
render(){
return(
    <div>

        
    </div>
)

}
}
    