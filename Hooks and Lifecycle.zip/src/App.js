import React,{Component} from 'react';
import Footer from './Footer';
import Header from './Header';
import Form from './form';
import NewForm from './newform';
import Dashboard from './Dashboard'
import Users from './Users';

class App extends Component {



  constructor(){  // is function which or invoke automatically when component is load
    super();//call to parent class constructor 
      console.log('inside constructor');

      //global state : global variabels
      this.state ={
            id:111, 
            name:'nitin'
            
          }
      

  }

  render(){  //template / html 


    //declare variable
    var a,b,c;
    a=44;
    b =4;
    c ="nitin sharma";

      return(

        <div>
              <Users/>
              <h1> First ReactJS App </h1>
              <Header/>
              <NewForm/>
              <p>
              Expression  { 2*4 -1}
              
                </p>

                <p>
              Data from variable : 
                        {a+b}
                  </p>
          <p>
            Name is {c}
            </p>
          
                 
                 <Form/> 

          <h2> Access data from state </h2>
          <p>
            Data from state { this.state.id }  |   {this.state.name}
            </p>

            <Footer/>
           
<Dashboard/>

          </div>
      );
  }
}

export default App;
