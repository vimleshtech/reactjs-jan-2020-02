import React,{Component} from 'react';
import { conditionalExpression } from '@babel/types';


export default class Create extends Component{

    constructor(){
        super();
        console.log('in cons');

        this.state ={data:[{id:1,completed:'test'},{id:1,completed:'4455'}]}

        this.fechdata = this.fechdata.bind(this);

    }
    
    static getDerivedStateFromProps(props, state){
        console.log("getDerivedStateFromProps")
        console.log(props, state)
        return {}
    }
    componentDidMount(){
        console.log("componentDidMount")
    }
    // ReactJS Component Updating Methods
    shouldComponentUpdate(){
        console.log("shouldComponentUpdate")
        return true
    }
    componentDidUpdate(){
        console.log("componentDidUpdate")
    }
    // ReactJS Component Unmounting Methods
    componentWillUnmount(){
        console.log("componentWillUnmount")
    }
    // custom methods
    handleChange(event) {
        this.setState({username: event.target.value});
    }

    
    async fechdata(){

        alert('hi');

     //  var response = await fetch('https://jsonplaceholder.typicode.com/todos');
       //var x = await response.json();
       this.setState({ data: {id:1,completed:false} });
        
        //.then(r=>r.json()).then(o=>console.log(o));
        console.log('after call');

        console.log(this.state.data);
        
    }

    
render(){

    
    console.log('in render');

return(
    <div>
        <h1> create ! </h1>
<input type='text' className='form-conrol'/>
<br/>
<input type='text' className='form-conrol'/>

<input type='submit' className='btn-primary' value='fetch api' onClick={this.fechdata}/>

      {/* {this.state.data.map((row,i)=><p key={i}>
                {row.completed}
         </p>)}   */}
    </div>
)

}
}
    