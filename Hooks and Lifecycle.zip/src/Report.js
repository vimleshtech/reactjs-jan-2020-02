import React,{Component} from 'react';
export default class Report extends Component{
render(){
return(
    <div>

        
    </div>
)

}
}
    