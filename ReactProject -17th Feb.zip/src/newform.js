import React, {Component} from 'react';

class Newform extends Component{
    constructor(){
        super();
this.state=
{
    f_name:"hi",
    l_name:"hello",
    i:0,
    newItems:[]

}
    }

    action=()=>{

        var name=this.refs.fname.value;
        var lastname=this.refs.lname.value;
        
        this.setState({f_name:name, l_name:lastname})

        var Items=this.state.newItems;

        console.log(Items)
        Items.push({f_name:name,l_name:lastname})

        this.setState({newItems:Items});

        //reset value in text field 
        this.refs.fname.value="";
        this.refs.lname.value="";
    }

    delrow=(i)=>{

        var Items=this.state.newItems;
        Items.splice(i,1);
        this.setState({newItems:Items});

    }

   
    editrow=(i)=>{
        console.log("edit "+i);

        var data = this.state.newItems;
        
        var  x=data[i].f_name;
        var  y=data[i].l_name;

        this.refs.fname.value=x;
        this.refs.lname.value=y;

        this.setState({i:i});
        
    }



    chkrow=(i)=>{
        console.log("mark "+i);
    }
update=()=>{

    console.log(i);
    var data = this.state.newItems;
    var i = this.state.i;

    console.log(data);

    var name=this.refs.fname.value;
    var lastname=this.refs.lname.value;

    data[i].f_name = name;
    data[i].l_name= lastname;
    console.log("index data "+data[i]);


    this.setState({newItems:data});

        //reset value in text field 
        this.refs.fname.value="";
        this.refs.lname.value="";
    
    
}


render(){



    return(
        <div className="container"> 

            <div className="jumbotron">
                <h1>Bootstrap Tutorial</h1>      
                <p>Bootstrap is the most popular HTML, CSS, and JS framework for developing responsive, mobile-first projects on the web.</p>
            </div>
            

            <form>First Name
        
         <input type="text" ref="fname"  className="form-control" /><br/>
        Last Name: <input type="text" ref="lname"  className="form-control" /><br/>

<input type="button" value="submit" onClick={this.action}  className="btn btn-primary"/>
<input type="button" value="update" onClick={this.update}   className="btn btn-danger"/>


            </form>

            <div>
               <p>
                   First Name is:{this.state.f_name}
                   </p>
                   <p>
                   Last Name:{this.state.l_name}
                    </p>
        </div>  

            <div>

            <table class="table table-hover">
                <thead>
                <tr>
                    <th>Firstname</th>
                    <th>Lastname</th>
                    <th>Email</th>
                </tr>
                </thead>
                <tbody>

                {this.state.newItems.map((data,i)=><tr> 

                    <td> 
                        {data.l_name}
                        </td>
                        <td> {data.f_name} 
                        </td>
                                    
                        <td> 
                            <input type="button" value="del" onClick={()=> this.delrow(i)}   className="btn btn-danger"/>
                        </td>

                        <td> 
                            <input type="button" value="edit" onClick={()=> this.editrow(i)}  className="btn btn-success"/>
                            </td>
                            <td>
                                    <input type="checkbox" value="del" onClick={()=> this.chkrow(i)} />
                            </td>

                                   
                    </tr> )}

                </tbody>


            </table>    
                
            </div>              
      </div>
    )
}
}
export default Newform