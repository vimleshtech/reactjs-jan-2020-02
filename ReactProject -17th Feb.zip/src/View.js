import React,{Component} from 'react';

export default class View extends Component{


    constructor(){
        super();
    }
    render(){

        return(<div>
                <h1>  in child </h1>
            <h1>

                    { this.props.name }
                </h1>

                <h1>

                    { this.props.email }
                </h1>


            </div>);
    }

}