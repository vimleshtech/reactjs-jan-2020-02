import React,{Component} from 'react';

import View from './View';

export default class Users extends Component{

    constructor(){
        super();

        this.state ={name:'',email:''}
    }


    btnfrm=()=>{

        var n,e;
        n = this.refs.name.value;
        e =this.refs.email.value;
        this.setState({name:n,email:e});
        console.log(this.state.name,this.state.email);

    }
    render(){
        return (
            <div>
                    <h1> Hi </h1>
                    <p>
                        Name :  <input type="text" ref="name" className="form-control"/>
                    </p>
                    <p>
                        Email :  <input type="text" ref="email" className="form-control"/>
                    </p>
                    
                    <p>
                        Button :  <input type="button" className="btn btn-info" value="Click Me" onClick={this.btnfrm} />
                    </p>

            <div>
                    <View name={this.state.name} email={this.state.email}/>
                </div>                    

            </div>

        );

    }
}
